// import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class Peta extends StatefulWidget {
  @override
  _PetaState createState() => _PetaState();
}

class _PetaState extends State<Peta> {
  final Set<Marker> _markers = {};
  final LatLng _currentPosition = LatLng(5.8926333, 95.3216784);
  // final
  GoogleMapController mapController;

  @override
  void initState() {
    _markers.add(
      Marker(
        markerId: MarkerId("5.8926333,95.3216784"),
        position: _currentPosition,
        icon: BitmapDescriptor.defaultMarker,
      ),
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return new Container(
      child: GoogleMap(
        mapType: MapType.normal,
        initialCameraPosition: CameraPosition(
          target: _currentPosition,
          zoom: 14.4746,
        ),
        markers: _markers,
        scrollGesturesEnabled: true,
        tiltGesturesEnabled: true,
        rotateGesturesEnabled: true,
        myLocationEnabled: true,
        zoomGesturesEnabled: true,
      ),
    );
  }
}
