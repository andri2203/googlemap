import 'package:flutter/material.dart';

// Import Halaman Untuk TabView
import './peta.dart' as peta;
import './situs.dart' as situs;
import './terdekat.dart' as terdekat;

void main() => runApp(new MaterialApp(
      title: "Sejarah Sabang",
      home: Beranda(),
    ));

class Beranda extends StatefulWidget {
  @override
  _BerandaState createState() => _BerandaState();
}

class _BerandaState extends State<Beranda> with SingleTickerProviderStateMixin {
  TabController controller;

  @override
  void initState() {
    controller = new TabController(vsync: this, length: 3);
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: new AppBar(
        title: new Text("Sejarah Sabang"),
      ),
      drawer: new Drawer(
        child: new ListView(
          children: <Widget>[
            new UserAccountsDrawerHeader(
              accountName: new Text("Sejarah Sabang"),
              accountEmail: new Text("Informasi Situs Sejarah Kota Sabang"),
              currentAccountPicture: new CircleAvatar(
                backgroundImage: new NetworkImage(
                    "http://bkpsdm.sabangkota.go.id/wp-content/uploads/2017/11/cropped-LOGO-KOTA-SABANG.png"),
                backgroundColor: Colors.white,
              ),
              decoration: new BoxDecoration(
                image: new DecorationImage(
                    image: new NetworkImage(
                        "https://cdns.klimg.com/merdeka.com/i/w/news/2017/11/30/914559/670x335/mengunjungi-tugu-kilometer-nol-indonesia-di-kota-sabang.jpg"),
                    fit: BoxFit.cover),
              ),
            ),
            new ListTile(
              title: new Text("Panduan"),
              trailing: new Icon(Icons.more_horiz),
            ),
            new ListTile(
              title: new Text("Setting"),
              trailing: new Icon(Icons.settings),
            )
          ],
        ),
      ),
      body: new TabBarView(
        controller: controller,
        children: <Widget>[
          // Letak View
          new peta.Peta(),
          new situs.Situs(),
          new terdekat.Terdekat(),
        ],
      ),
      bottomNavigationBar: new Material(
        color: Colors.blue,
        child: new TabBar(
          controller: controller,
          tabs: <Widget>[
            new Tab(
              icon: new Icon(Icons.map),
            ),
            new Tab(
              icon: new Icon(Icons.list),
            ),
            new Tab(
              icon: new Icon(Icons.pin_drop),
            ),
          ],
        ),
      ),
    );
  }
}
