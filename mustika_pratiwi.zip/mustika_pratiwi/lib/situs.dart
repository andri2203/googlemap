import 'package:flutter/material.dart';

class Situs extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Container(
      child: new Center(
        child: new Column(
          children: <Widget>[
            new Padding(
              padding: new EdgeInsets.all(20.0),
            ),
            new Text(
              "Daftar Situs Sejarah",
              style: new TextStyle(fontSize: 30.0),
            )
          ],
        ),
      ),
    );
  }
}
